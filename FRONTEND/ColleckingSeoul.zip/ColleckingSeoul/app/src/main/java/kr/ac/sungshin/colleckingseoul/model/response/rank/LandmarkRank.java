package kr.ac.sungshin.colleckingseoul.model.response.rank;

/**
 * Created by kwonhyeon-a on 2018. 5. 16..
 */

public class LandmarkRank {
    private String name;

    public LandmarkRank(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
