package kr.ac.sungshin.colleckingseoul.mypage;

/**
 * Created by LG on 2018-05-17.
 */

public class MyVisitItem {
}
